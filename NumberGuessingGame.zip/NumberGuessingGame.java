import java.util.Random;
import java.util.Scanner;

/**
 * Play a Number Guessing Game
 */

/**
 * @author Gopala Bobba
 *
 */
public class NumberGuessingGame {

	/*
	 * Enumeration for User entry values for validation
	 */
	public enum results {
		higher, lower, yes, end
	}

	/*
	 * Number Guessing between fixed values
	 */
	static final int minValue = 1;
	static final int maxValue = 100;
	
	/*
	 * Initial values for lowerValue and higherValue;
	 */
	int lowerValue = 1;
	int higherValue = 100;
	
	/**
	 * main method to find out the number guessing
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		NumberGuessingGame ngGame = new NumberGuessingGame();
		ngGame.startGame(sc);
		ngGame.getNumber(sc);
		sc.close();

	}

	/**
	 * Get User Input and validate
	 * @param sc
	 **/
	private void getNumber(Scanner sc) {

		boolean correctEnd = true;
		int guessNumber = new Random().nextInt(100);
		String enumValues = "";
		for (results name: results.values()) {
			enumValues += (!enumValues.equals("")?", ":"") + name;
		}
		System.out.println("User input valid values are " + enumValues);
		/*
		 * Loop the User entry until input is 'yes' or 'end'
		 */
		while (correctEnd) {
			try {
				System.out.println("Computer : Is the number " + guessNumber + "?");
				System.out.print("User     : ");
				String guessedValue = sc.next().toLowerCase();

				// validate user input with enumeration values
				results.valueOf(guessedValue);
				
				// create new guess number when the user input is either 'higher' or 'lower'
				if (guessedValue.equalsIgnoreCase(results.higher.toString()) ||
					guessedValue.equalsIgnoreCase(results.lower.toString())) {
					if (guessedValue.equalsIgnoreCase(results.higher.toString())) {
						higherValue = guessNumber;
					} else if (guessedValue.equalsIgnoreCase(results.lower.toString())) {
						lowerValue = guessNumber;
					}
					guessNumber = this.getGuessedNumber(guessNumber);
				} else {
					
					//display 'Congratulations' message when user entry is 'yes'
					if (guessedValue.equalsIgnoreCase(results.yes.toString())) {
						System.out.println("Congratulations! Computer is guessed your number i.e., " + guessNumber);
					}

					// End the game when user entry is 'yes' or 'end'
					if (guessedValue.equalsIgnoreCase(results.yes.toString()) ||
						guessedValue.equalsIgnoreCase(results.end.toString())) {
						this.gameEnd();
					}
				}
			} catch (Exception ex) {
				// Display error message when user entry is invalid value 
				System.out.println("Enter valid value only");
			}
		}
	}
	
	/**
	 * Calculate new guessing number based on previous guessed number
	 * @param n
	 * @return
	 */
	private int getGuessedNumber(int n) {
		int num = 0;
		if (n < lowerValue) {
			num = ( minValue + lowerValue) / 2;
		} else if (n >= lowerValue && n <= higherValue) {
			num = (lowerValue + higherValue) /2;
		} else if (n > higherValue) {
			num = ( higherValue + maxValue) / 2;
		}
		return num;
	}

	/**
	 * Start the game when User enters 'ready' or end the game when user enters 'end'
	 * @param sc
	 */
	private void startGame(Scanner sc) {
		String ready = null;
		boolean startGame = true;
		while (startGame) {
			System.out.print("Enter 'ready' when you choose number between 1 and 100 in your mind or enter 'end' for exit the game : ");
			ready = sc.next().toLowerCase();
			if ("ready".equalsIgnoreCase(ready)) {
				startGame = false;
			} else if ("end".equalsIgnoreCase(ready)) {
				this.gameEnd();
			} else {
				System.out.println("Invalid value entered. Try again");
			}
		}
	}

	/**
	 * End the game
	 */
	private void gameEnd() {
		System.out.println("Number guessing game ended.");
		System.exit(0);
	}


}
